
document.getElementById('showDialog').addEventListener('click', function() {
  alert('你好！這是一個對話視窗');
});
